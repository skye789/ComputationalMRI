function n = numel(ob, varargin)
% help numel
% says that numel will be called when subsref is invoked.
% but i cannot get this to work.
%whos
%dbstack
%length(varargin)
n = 1;
