 function out = plus(ob, num)
%function out = plus(ob, num)

out = 'ok (testing freemat overloading)'
